package MyFirstPkg;

public class ArithmeticOperator {

	public static void main(String[] args) {
		
		int a=6;
		int b=10;
		
		int r=a/b;
		System.out.println(r);
		
		
		
		
		
		
		

	}

}
