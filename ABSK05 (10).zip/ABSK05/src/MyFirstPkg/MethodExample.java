package MyFirstPkg;

class A
{
	void display2()
	{
		System.out.println("Hello");
	}
}

public class MethodExample {
	
	
	void test(int x,int y)
	{
		int z=x+y;
		System.out.println(z);
	}
	
	void display(float p,float q,float j)
	{
		float r=p*q*j;
		System.out.println(r);
		
	}

	public static void main(String[] args) {
		
		
		MethodExample obj=new MethodExample();
		obj.test(23, 32);
		obj.display(32.5f, 67.6f, 88.9f);
		
		A obj1=new A();
		obj1.display2();
		
		

	}

}
