package AccessModifier1Ex;

//import EncapsulationAndAccessModifiers.AM3;
//
//public class UsingDefaultNew {
//
//	public static void main(String[] args) {
//	
//		AM3 obj=new AM3();
//		obj.display();
//		
//		
//
//	}
//
//}
