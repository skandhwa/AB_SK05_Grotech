package InheritanceConcepts;

class Animal
{
	String name;
	
	Animal(String n)
	{
		name=n;
	}
	
	void eat()
	{
		System.out.println("Animals eat");
	}
}


class Dog9 extends Animal
{
	String breed;
	Dog9(String m,String b)
	{
		super(name);
		breed=b;
	}
	
	
	
}


public class SuperExamples {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
