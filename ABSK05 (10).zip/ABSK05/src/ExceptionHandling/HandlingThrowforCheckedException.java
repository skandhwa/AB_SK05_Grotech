package ExceptionHandling;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class HandlingThrowforCheckedException {
	
	public static void m1(int id) throws FileNotFoundException 
	{
		FileReader f=new FileReader("D:\\DashBoard Mock API.txt");
		BufferedReader br=new BufferedReader(f);
	    if(id==1234)
	     {
		System.out.println("You have the access to use the file");
	     }
	     else
	     {
		throw new FileNotFoundException("You are not Authorized to access");
	     }
		
		
	}
	
	

	public static void main(String[] args) throws FileNotFoundException {
		
		HandlingThrowforCheckedException.m1(1239);
		
		

	}

}
