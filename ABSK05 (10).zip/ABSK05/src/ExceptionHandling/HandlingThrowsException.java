package ExceptionHandling;

public class HandlingThrowsException {

	public static void main(String[] args) throws InterruptedException {
		
		
		Thread.sleep(3000);
		

	}

}
