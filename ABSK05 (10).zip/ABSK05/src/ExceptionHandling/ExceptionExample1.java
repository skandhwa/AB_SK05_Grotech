package ExceptionHandling;

public class ExceptionExample1 {

	public static void main(String[] args) {
		
		try
		{
		int x=20/0;
		System.out.println(x);
		}
		catch(ArithmeticException e)
		{
			System.out.println("caught with "+e);
		}
		
		
		int a=20+40;
		System.out.println(a);
		
		
		

	}

}
