package ExceptionHandling;

public class ExceptionExample2 {

	public static void main(String[] args) {
		
		try
		{
		int a[]=new int[5];
		a[0]=3;
		a[1]=5;
		a[2]=31;
		a[3]=15;
		a[4]=32;
		a[5]=35;
		
		for(int i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		}
		
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Caught with "+e);
		}
		
		
		System.out.println();
		
		int c=20+40;
		System.out.println("The sum of two elements is "+c);

	}

}
