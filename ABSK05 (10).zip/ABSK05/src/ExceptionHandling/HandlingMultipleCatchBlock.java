package ExceptionHandling;

public class HandlingMultipleCatchBlock {

	public static void main(String[] args) {
		
		try
		{
		
		int a[]=new int[5];
		a[6]=20/10;
		
		int x=40/0;
		
		}
		
		catch(ArrayIndexOutOfBoundsException e)
		{
			System.out.println("Caught with "+e);
		}
		
		catch(ArithmeticException e)
		{
			System.out.println("Caught with "+e);
		}
		
		
		System.out.println();
		
		int c=20+40;
		System.out.println("The sum of two elements is "+c);
		
		

	}

}
