package ExceptionHandling;

import java.io.IOException;

public class HandlingIoException {

	public static void main(String[] args) throws IOException {
		
		
		throw new IOException("error");

	}

}
