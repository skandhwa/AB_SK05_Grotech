package EncapsulationAndAccessModifiers;

class PREx
{
	private int x=20;
	
	private void display()
	{
		int y=x+30;
	}
	
}

class PREy extends PREx
{
	void test()
	{
		System.out.println(super.x);
	}
}


public class PrivateAccessModifiers {

	public static void main(String[] args) {
		
		
		

	}

}
