package CollectionsInterface;

import java.util.Vector;

public class VectorExample {

	public static void main(String[] args) {
		
		Vector<String> v1=new Vector<String>();
		v1.add("c#");
		v1.add("python");
		v1.add("c++");
		v1.add("postman");
		
		for(String x:v1)
		{
			System.out.println(x);
		}
		

	}

}
