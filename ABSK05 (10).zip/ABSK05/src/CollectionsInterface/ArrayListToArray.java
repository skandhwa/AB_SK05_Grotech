package CollectionsInterface;

import java.util.ArrayList;

public class ArrayListToArray {

	public static void main(String[] args) {
		
		ArrayList<String> li=new ArrayList<String>();
		li.add("python");
		li.add("java");
		li.add("html");
		li.add("css");
		
		int x=li.size();
		
		
		
		String []arr=new String[x];
		
		li.toArray(arr);
		
		for(String y:arr)
		{
			System.out.println(y);
		}
		
		

	}

}
