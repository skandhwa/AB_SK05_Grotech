package CollectionsInterface;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class ListInterfaceEx {

	public static void main(String[] args) {
		
		List<Integer> li=new ArrayList<Integer>();
		li.add(23);
		li.add(45);
		li.add(67);
		li.add(67);
		li.add(67);
		li.add(1,99);
		
		//Using a for loop
		
		for(int k:li)
		{
			System.out.println(k);
		}
		
		
		System.out.println();
		
		System.out.println();
		
		
		Iterator<Integer> itr=li.iterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
System.out.println();
		
		System.out.println();
		
		System.out.println(li);
		
		
		

	}

}
