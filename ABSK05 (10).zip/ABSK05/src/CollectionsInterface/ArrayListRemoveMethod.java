package CollectionsInterface;

import java.util.ArrayList;
import java.util.List;

public class ArrayListRemoveMethod {

	public static void main(String[] args) {
		
		List<Object> li=new ArrayList<Object>();
		li.add(34);
		li.add(67);
		li.add("Saurabh");
		li.add(true);
		li.add('A');
		li.add(24.56f);
		
		
	boolean flag2=	li.isEmpty();
	System.out.println("Is Empty "+flag2);
		
	int x=	li.size();
		
		try
		{
		
		li.remove("Saurabh");
		
		}
		
		catch(IndexOutOfBoundsException e)
		{
			System.out.println("caught with "+e);
		}
		
		
		for(Object y:li)
		{
			System.out.println(y);
		}
		
		
		System.out.println("I will run");
		

	}

}
