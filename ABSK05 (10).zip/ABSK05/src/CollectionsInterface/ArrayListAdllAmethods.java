package CollectionsInterface;

import java.util.ArrayList;
import java.util.List;

public class ArrayListAdllAmethods {

	public static void main(String[] args) {
		
		
		
		List<Integer> li=new ArrayList<Integer>();
		li.add(23);
		li.add(45);
		li.add(67);
		li.add(97);
		
		
		List<Integer> li2=new ArrayList<Integer>();
		li2.add(93);
		li2.add(65);
		li2.add(37);
		li2.add(57);
		
		
		li.addAll(li2);
		
		for(int k:li)
		{
			System.out.println(k);
		}
		
		
		//li.clear();
		
		li.removeAll(li);
		
		
		
		System.out.println("After clearing elements are");
		
		for(int k:li)
		{
			System.out.println(k);
		}


	}

}
