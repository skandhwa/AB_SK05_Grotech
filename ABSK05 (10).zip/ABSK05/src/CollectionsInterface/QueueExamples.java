package CollectionsInterface;

import java.util.PriorityQueue;
import java.util.Queue;

public class QueueExamples {

	public static void main(String[] args) {
		
		Queue<String> q1=new PriorityQueue<String>();
		q1.add("c#");
		q1.add("Java");
		q1.add("c++");
		q1.add("php");
		
		for(String x:q1)
		{
			System.out.println(x);
		}
		
		System.out.println("After deleting");
		System.out.println();
		System.out.println();
		q1.remove();
		q1.remove();
		
		for(String x:q1)
		{
			System.out.println(x);
		}
		
		

	}

}
