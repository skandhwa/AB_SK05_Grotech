package CollectionsInterface;

import java.util.Stack;

public class StackExamples {

	public static void main(String[] args) {
		
		Stack<Integer> stk=new Stack<Integer>();
		stk.push(23);
		stk.push(56);
		stk.push(89);
		stk.push(99);
		stk.pop();
		stk.pop();
		
		for(Integer x:stk)
		{
			System.out.println(x);
		}
		

	}

}
