package SetAndMapConcepts;

import java.util.HashSet;
import java.util.Set;

public class SetExample {

	public static void main(String[] args) {
		
		Set<String> s1=new HashSet<String>();
		s1.add("Java");
		s1.add("C#");
		s1.add("php");
		s1.add("C#");
		s1.add("python");
		s1.add(null);
		s1.add(null);
		
		for(String x:s1)
		{
			System.out.println(x);
		}
		
		
		
		
		

	}

}
