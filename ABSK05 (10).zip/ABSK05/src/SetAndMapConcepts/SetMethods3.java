package SetAndMapConcepts;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SetMethods3 {

	public static void main(String[] args) {
		
		List<Integer> li=new ArrayList<Integer>();
		li.add(23);
		li.add(45);
		li.add(67);
		li.add(97);
		li.add(53);
		li.add(83);
		
		Set<Integer> s1=new HashSet<Integer>();
		s1.add(23);
		s1.add(13);
		s1.add(53);
		s1.add(83);
		s1.add(93);
		
		
		s1.retainAll(li);
		
		for(int x:s1)
		{
			System.out.println(x);
		}
		
		System.out.println("After removing elements are");
		s1.remove(1);
		
		for(int y:s1)
		{
			System.out.println(y);
		}
		
		
		

	}

}
