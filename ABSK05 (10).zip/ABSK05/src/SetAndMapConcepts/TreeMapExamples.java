package SetAndMapConcepts;

import java.util.Map;
import java.util.TreeMap;

public class TreeMapExamples {

	public static void main(String[] args) {
		
		TreeMap<String,Integer> mp=new TreeMap<String,Integer>();
		
		mp.put("Amit",100);
		mp.put("Aakash",400);
		mp.put("Ashok",300);
		mp.put("Aman",900);
		
		
		for(Map.Entry m:mp.entrySet())
		{
			System.out.print(m.getKey()+"  " );
			System.out.println(m.getValue());
		}
		
		
		System.out.println("Descending map is "+mp.descendingMap());
		System.out.println("Head map is "+mp.headMap("Aman",true));
		System.out.println("Tail map is "+mp.tailMap("Aman",false));
	}

}
