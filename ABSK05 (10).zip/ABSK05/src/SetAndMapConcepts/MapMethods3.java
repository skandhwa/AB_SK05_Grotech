package SetAndMapConcepts;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class MapMethods3 {

	public static void main(String[] args) {
		
		Map<Integer,String>mp=new HashMap<Integer,String>();
		mp.put(23,"Rohan");
		mp.put(34, "Mohan");
		mp.put(23,"Harsh");
		mp.put(54, "Rohit");
		
		
		Map<Integer,String>mp2=new HashMap<Integer,String>();
		mp2.put(23,"Rohan");
		mp2.put(34, "Mohan");
		mp2.put(23,"Harsh");
		mp2.put(54, "Mohit");
		mp2.put(null, "Harshit");
		mp2.put(65, null);
		mp2.put(49, null);
		
		mp2.putIfAbsent(89, "Tom");
		
		System.out.println("Using Put if absent   "+mp2);
		
		int size=mp2.size();
		System.out.println("Size of map is "+size);
		
		
	boolean flag=	mp.equals(mp2);
	
	System.out.println(flag);
	
	System.out.println("Using get method");
	String value=mp.get(23);
	System.out.println(value);
	
	Set <Integer> s1=mp.keySet();
	
	System.out.println("Set view of map is  "+s1);
	
	
	mp2.remove("Harsh");
	
	System.out.println("After removing 54 the map is "+mp2);
	
	
	

	}

}
