package SetAndMapConcepts;

import java.util.TreeSet;

public class TreeSetExamples2 {

	public static void main(String[] args) {
		
	    TreeSet<Integer> s1=new TreeSet<Integer>();
		
			s1.add(34);
			s1.add(56);
			s1.add(67);
			s1.add(43);
			s1.add(12);
			s1.add(89);
			
		System.out.println("Reverse Set is "+s1.descendingSet());	
		
		System.out.println("Head Set is "+s1.headSet(34,true));
		
		System.out.println("Tail Set is "+s1.tailSet(56,false));
			
		System.out.println("Sub Set is "+s1.subSet(56,false,89,true));
	}

}
