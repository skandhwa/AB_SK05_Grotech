package SetAndMapConcepts;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class MapMethods2 {

	public static void main(String[] args) {
		
		Map<Character,Object> mp=new HashMap<Character,Object>();
		mp.put('A',"Saurabh");
		mp.put('B',1234);
		mp.put('C',45.67f);
		mp.put('D','H');
		
		Map<Character,Object> mp2=new HashMap<Character,Object>();
		mp2.put('G',"Gaurabh");
		mp2.put('H',8234);
		mp2.put('C',95.67f);
		
		
		Set<Character> s1=mp2.keySet();
		
	System.out.println("Set view of map is "+s1);	
		
		mp.putAll(mp2);
		
		for(Map.Entry x:mp.entrySet())
		{
			System.out.print(x.getKey()+" ");
			System.out.println(x.getValue());
		}
		
	boolean flag=	mp.containsKey('G');
	System.out.println("Is the map contains the key "+flag);
		
	boolean flag2=	mp.containsValue(123466);
	System.out.println("Is the map contains the value "+flag2);
		

	}

}
