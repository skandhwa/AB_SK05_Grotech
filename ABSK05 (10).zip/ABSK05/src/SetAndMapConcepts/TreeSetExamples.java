package SetAndMapConcepts;

import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetExamples {

	public static void main(String[] args) {
		
		TreeSet<String> s1=new TreeSet<String>();
		
		s1.add("Zaheer");
		s1.add("Manoj");
		s1.add("Ramesh");
		s1.add("Biswajit");
		s1.add("Adam");
		s1.add("Harsh");
		
		for(String x:s1)
		{
			System.out.println(x);
		}
		
		System.out.println("Reversing the order");
		
		Iterator itr=s1.descendingIterator();
		
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		

	}

}
