package SetAndMapConcepts;

import java.util.HashSet;
import java.util.Set;

public class SetRemoveAll {

	public static void main(String[] args) {
		
		Set<Integer> s1=new HashSet<Integer>();
		s1.add(23);
		s1.add(13);
		s1.add(53);
		s1.add(83);
		s1.add(93);
		
		int k=s1.size();
		System.out.println("Size of set is " +k);
		
		
		Set<Integer> s2=new HashSet<Integer>();
		s2.add(23);
		s2.add(13);
		s2.add(53);
		
		
		s1.removeAll(s2);
		
		for(Integer x:s1)
		{
			System.out.println(x);
		}
		
		
		

	}

}
