package SetAndMapConcepts;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SetExample2 {

	public static void main(String[] args) {
		
		Set<Integer> s1=new HashSet<Integer>();
		s1.add(23);
		s1.add(13);
		s1.add(53);
		s1.add(83);
		s1.add(93);
		
		
		List<Integer> li=new ArrayList<Integer>();
		li.add(23);
		li.add(45);
		li.add(83);
		li.add(97);
		
		
		s1.addAll(li);
		
		for(Integer y:s1)
		{
			System.out.println(y);
		}
		
		////clear method
		System.out.println("after clearing elements are ");
		s1.clear();
		for(Integer z:s1)
		{
			System.out.println(z);
		}
		
		
		
		
		
		
		
		
		
		

	}

}
