package TakingInputFromUser;

import java.util.Scanner;

public class SwitchCaseExample {

	public static void main(String[] args) {
		
		int num;
		System.out.println("Enter the rating between 1 to 5");
		
		Scanner sc=new Scanner(System.in);
		num=sc.nextInt();
		
		switch(num)
		
		{
		
		case 1:
			System.out.println("Your Band is A");
			break;
			
		case 2:
			System.out.println("Your Band is B");
			break;
			
		case 3:
			System.out.println("Your Band is C");
			break;
		
		case 4:
			System.out.println("Your Band is D");
			break;
		case 5:
			System.out.println("Your Band is E");
			break;
			
			
			default:
				System.out.println("You have entered an invalid input");
		
		
		
		}
		
		
		
		
		
		
		

	}

}
