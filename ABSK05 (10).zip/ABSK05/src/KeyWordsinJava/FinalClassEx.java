package KeyWordsinJava;

final class Employee6
{
	void display()
	{
		System.out.println("Employee created");
	}
}

class Employee11 extends Employee6
{
	void display2()
	{
		System.out.println("New Employee created");
	}
}
public class FinalClassEx {

	public static void main(String[] args) {
		
		Employee11 obj=new Employee11();
		obj.display();
		obj.display2();
		
		
		
		
		

	}

}
