package KeyWordsinJava;


class Bank2
{
	final static int getROI(int x,int y)
	{
		return x+y;
	}
}

class SBI2 extends Bank2
{
	int getROI(int x,int y)
	{
		return x+y;
	}
}




public class FinalMethodsEx {

	public static void main(String[] args) {
		

	}

}
