package StringConcepts;

public class StringSwapWithoutThirdVariable {

	public static void main(String[] args) {
		
		String str="Good";
		String str2="Bad";
		
		
		

	}

}
