package StringConcepts;

public class StringMethods2 {

	public static void main(String[] args) {
		
		String str="Indian";
		String str1=str.substring(3);
//		
		System.out.println(str1);
		
		//String str2=str.substring(1,6);
//		System.out.println(str2);
//		
	
//	boolean flag=	str.contains("cit ");
//	System.out.println(flag);
	
	////saurabh,skandhwa@1234
		
		
		

	}

}
