package StringConcepts;

public class StringDeclaration {

	public static void main(String[] args) {
		
		String str="Indian";////Using String Literal
		
	 str=	str.concat("Citizen");
		
		System.out.println(str);
		
		
		String str1="Indians";
		
		
		String str2=new String ("Bjp");
		
		
		
		
		
		
		
		
		
		
		
		

	}

}
