package StringConcepts;

public class StringMethods6 {

	public static void main(String[] args) {
		
		
		String str="John loves to swim and also loves to read book ";
		
	int x=	str.indexOf("to",13);
	
	System.out.println(x);
		

	}

}
