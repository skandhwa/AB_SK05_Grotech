package StringConcepts;

public class StringMethods5 {

	public static void main(String[] args) {
		
//		String str="Java Selenium Python Ruby";
//		
//	String[]arr=	str.split(" ");
//	
//	for(String x:arr)
//	{
//		System.out.println(x);
//	}
//	
//	
//	int y=arr[0].length();
//	System.out.println(y);
	
	
	String str2="saurabh@1234@pw1234@TCS";
	String k[]=	str2.split("@");
	
	for(String l:k)
	{
		System.out.println(l);
	}
	
	
	
	System.out.println(k[1]);

	}
	
	//saurabhtcsinfosys

}
