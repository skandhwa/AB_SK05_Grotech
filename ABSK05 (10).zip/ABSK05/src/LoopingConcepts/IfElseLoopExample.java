package LoopingConcepts;

public class IfElseLoopExample {

	public static void main(String[] args) {
		
		int a=10*3;
		int b=30;
		
		
		if(a>=b)
		{
			System.out.println("a is equal or max to b");
		}
		
		else
		{
			System.out.println("b is max");
		}
		
		
		

	}

}
