package AbstractionConcepts;

interface Bank
{
	float rateOfIntrest();
	float timeData();
	
}

class SBI implements Bank
{
	public float rateOfIntrest()
	{
		return 8.5f;
	}
	
	public float timeData()
	{
		return 8;
	}
}

class HDFC implements Bank
{
	
	public float rateOfIntrest()
	{
		return 9.5f;
	}
	
	public float timeData()
	{
		return 7;
	}
	
}

public class BankInterface {

	public static void main(String[] args) {
		
		Bank ref=new SBI();
	System.out.println(ref.rateOfIntrest());	
	System.out.println(	ref.timeData());
	
	Bank ref1=new HDFC();
	System.out.println(ref1.rateOfIntrest());	
	System.out.println(	ref1.timeData());
		

	}

}
