package AbstractionConcepts;

abstract class Emp13
{
	void display()
	{
		System.out.println("Method display");
	}
	
	abstract void message();
	
	void generaldetails()
	{
		String mame;
		int age;
		
	}
	
	abstract void salarydetails();
	
	
}

class Empl4 extends Emp13
{
	void message()
	{
		System.out.println("Hello");
		
	}
	
}

public class AbstractClassEx {

	public static void main(String[] args) {
		
		Emp13 ref=new Empl4();
		ref.message();
		ref.display();
		
		
		
		

	}

}
