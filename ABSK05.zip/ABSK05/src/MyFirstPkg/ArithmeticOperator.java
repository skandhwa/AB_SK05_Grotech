package MyFirstPkg;

public class ArithmeticOperator {

	public static void main(String[] args) {
		
		int a=750;
		int b=60;
		
		int r=a/b;
		System.out.println(r);
		
		
		
		
		
		
		

	}

}
