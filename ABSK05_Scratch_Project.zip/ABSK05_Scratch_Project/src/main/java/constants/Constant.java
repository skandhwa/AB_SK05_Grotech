package constants;

public class Constant {

	public static final String URL="C:\\Users\\saura\\Downloads\\TestData23JulyNew.xlsx";
	public static final String PropertyFilePath="src\\main\\java\\constants\\Global.properties";
	
	
}
