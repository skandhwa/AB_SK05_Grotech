package stepDefinition;

import org.openqa.selenium.WebDriver;

import Utilities.BaseClass;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition extends BaseClass {
	
	WebDriver driver=BaseClass.initializeDriver();
	
	
	
	
	@Given("User opens the URL of the application")
	public void user_opens_the_url_of_the_application() {
	   
	}

	@Given("User will enter the username with {string}")
	public void user_will_enter_the_username_with(String string) {
	   
	}

	@Given("User will enter the password with {string}")
	public void user_will_enter_the_password_with(String string) {
	  
	}

	@When("User clicks on Login button")
	public void user_clicks_on_login_button() {
	    
	}

	@Then("User will be able to login to the application")
	public void user_will_be_able_to_login_to_the_application() {
	   
	}

	

}
