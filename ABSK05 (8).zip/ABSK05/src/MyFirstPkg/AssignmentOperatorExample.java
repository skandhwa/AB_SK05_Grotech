package MyFirstPkg;

public class AssignmentOperatorExample {

	public static void main(String[] args) {
		
		int x=100;
		//x+=10;///x=x+10
		//x*=14;//x=x*10
		
		x%=12;
		
		
		System.out.println(x);
		
		

	}

}
