package ArrayConcepts;

public class JaggedArray {

	public static void main(String[] args) {
		
		int a[][]=new int [3][];
		a[0]=new int [3];
		a[1]=new int [4];
		a[2]=new int [2];
		
		int count=0;
		
		for(int i=0;i<a.length;i++)//i=0,0<3//
		{
			for(int j=0;j<a[i].length;j++)//j=0,j<3
			{
				a[i][j]=count++;///a[0][0]=0++
			}
		}
		
		System.out.println("Elements of array are");
		
		
		for(int i=0;i<a.length;i++)//
		{
			for(int j=0;j<a[i].length;j++)
			{
				System.out.print(a[i][j]+" ");
			}
			System.out.println();
		}
		

	}

}
