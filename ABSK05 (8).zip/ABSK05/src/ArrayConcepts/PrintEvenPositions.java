package ArrayConcepts;

public class PrintEvenPositions {

	public static void main(String[] args) {
		
		int []a= {12,34,56,78,99,21};
		
		for(int i=1;i<a.length;i=i+2)///i=2,2<6//i=4
		{
			System.out.println(a[i]);
			
			if(a[i]%2==0)
			{
				System.out.println(a[i]+" "+"is an even number");
			}
			
			
			//a[2]//a[4]
		}
		

	}

}
