package ArrayConcepts;

public class ArraySortingExample {

	public static void main(String[] args) {
		
		int []a= {2,43,12,1};
		
		for(int i=0;i<a.length;i++)//i=0,0<4//i=1,1<4//i=2,2<4
		{
			for(int j=i+1;j<a.length;j++)//j=3,3<4
			{
				if(a[i]<a[j])//a[2]>a[3]
				{
					int t;
					t=a[i];
					a[i]=a[j];
					a[j]=t;
				}
			}
			
			System.out.println(a[i]);
		}
		
		
		
		
		

	}

}
