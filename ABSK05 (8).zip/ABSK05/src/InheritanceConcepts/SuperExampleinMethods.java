package InheritanceConcepts;

class Mammal
{
	void eat()
	{
		System.out.println("all mammals eat");
	}
}

class Human extends Mammal
{
	void eat()
	{
		System.out.println("all humans eat");
	}
	
}


class Sapiens extends Human
{
	void bark()
	{
		System.out.println("dog barks");
	}
	
	void eat()
	{
		System.out.println("dog also eats");
	}
	
	void work()
	{
		bark();
		eat();
		super.eat();
	}
	
	
}

public class SuperExampleinMethods {

	public static void main(String[] args) {
		
		Sapiens obj=new Sapiens();
		obj.work();
		
		
		
		
		

	}

}
