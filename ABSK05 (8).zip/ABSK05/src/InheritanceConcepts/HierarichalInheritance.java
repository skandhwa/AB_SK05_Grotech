package InheritanceConcepts;

class A6
{
	void test()
	{
		System.out.println("Hello I am test");
	}
}

class B6 extends A6
{
	void message()
	{
		System.out.println("I am message");
	}
}


class C6 extends A6
{
	void display()
	{
		System.out.println("I am display");
	}
}

class D6 extends A6
{
	void test2()
	{
		System.out.println("I am test2");
	}
}


public class HierarichalInheritance {

	public static void main(String[] args) {
		 D6 obj=new D6();
		 obj.test2();
		 obj.test();

	}

}
