package ExceptionHandling;

public class HandlingNumberFormatException {

	public static void main(String[] args) {
		
		try
		{
		String str="abc";
	int x=Integer.parseInt(str);
	
		}
		
		catch(NumberFormatException e)
		{
			System.out.println("caught with "+e);
		}
	

	System.out.println();
	
	int c=20+40;
	System.out.println("The sum of two elements is "+c);
	

	}

}
