package StringConcepts;

public class StringMethods4 {

	public static void main(String[] args) {
		
		String str="India";
	boolean flag=	str.isEmpty();
	System.out.println(flag);
	
	
	String str1="Selenium java python C# java";
	str1=str1.replace('a', 'e');
	System.out.println(str1);
		
		

	}

}
