package StringConcepts;

public class StringMethods8 {

	public static void main(String[] args) {
		
		
		String str="India";
	char []ch=	str.toCharArray();
	
	for(char x:ch)
	{
		System.out.println(x);
	}

	}

}
