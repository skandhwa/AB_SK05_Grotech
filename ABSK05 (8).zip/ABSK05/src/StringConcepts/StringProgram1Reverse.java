package StringConcepts;

import java.util.Scanner;

public class StringProgram1Reverse {

	public static void main(String[] args) {
		
		String str;
		System.out.println("Enter the String");
		String revstr="";
		
		Scanner sc=new Scanner(System.in);
		str=sc.nextLine();
		
//		for(int i=str.length()-1;i>=0;i--)//i=4,4>=0//i=3,3>=0
//		{
//			revstr=revstr+str.charAt(i);//
//		}
//
//		System.out.println(revstr);
		
		
	
		
		if(str.equalsIgnoreCase(revstr)==true)
		{
			System.out.println("Both String are Palindrome");
		}
		else
		{
			System.out.println("Both String are not Palindrome");
		}
		
	}

}
