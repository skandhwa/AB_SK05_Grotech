package StringConcepts;

public class StringMethods3 {

	public static void main(String[] args) {
		
		
		String str1="Selenium";
		String str2="sELEnium ";
		
	boolean flag=	str1.equalsIgnoreCase(str2);
	System.out.println(flag);
	
	String str3="Indian";
	String str4="Republic";
	
	String str5=str4.concat(str3);
	System.out.println(str5);
	

	}

}
