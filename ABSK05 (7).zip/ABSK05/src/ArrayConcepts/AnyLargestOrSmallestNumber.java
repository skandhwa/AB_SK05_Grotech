package ArrayConcepts;

import java.util.Arrays;

class ThirdLargest
{
	public static int getSecondLargest(int a[],int total)
	{
		for(int i=0;i<total;i++)//i=0,0<4//i=1,1<4//i=2,2<4
		{
			for(int j=i+1;j<total;j++)//j=3,3<4
			{
				if(a[i]<a[j])//a[2]>a[3]
				{
					int t;
					t=a[i];
					a[i]=a[j];
					a[j]=t;
				}
			}
		
		
	}
		
		return a[total-2];
	}


public class AnyLargestOrSmallestNumber {
	
	public static void main(String[] args) {
		
		int a[]= {6,19,2,4,7,1,3,56,14,34,78,11,8,45,98};
		int x=a.length;
	System.out.println(ThirdLargest.getSecondLargest(a,x));	
		
		
		

	}

}
}
