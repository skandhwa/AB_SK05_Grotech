package ArrayConcepts;

import java.util.Arrays;

public class ArrayMethods {

	public static void main(String[] args) {
		
		int a[]= {6,2,3,4};
		int b[]= {1,2,3,4};
		
	boolean flag=	Arrays.equals(a,b);
	System.out.println(flag);
	
	int x=Arrays.compare(a,b);
	System.out.println(x);
	
String str=	Arrays.toString(a);
System.out.println(str);


		

	}

}
