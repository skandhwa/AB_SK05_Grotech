package ArrayConcepts;

public class SumOfAllElements {

	public static void main(String[] args) {
		
		int a[]= {2,9,17,14};
		int sum=0;
		for(int i=0;i<a.length;i++)///i=0,0<4//i=1,1<4
		{
			sum=sum+a[i];//sum=0+2=2//sum=2+9=11//sum=11+17=28//sum=28+14=42
		}
		
		System.out.println("The sum of all the elements is "+sum);
		
		

	}

}
