package ArrayConcepts;

public class ArrayDeclaration {

	public static void main(String[] args) {
		
//		int a[]=new int[5];
//		a[0]=3;
//		a[1]=5;
//		a[2]=31;
//		a[3]=15;
//		a[4]=32;
//		a[5]=35;
		
		
		
		int b[]= {12,45,67,89};
	int x=	b.length;
		
		
		for(int i=0;i<x;i++)//i=0,0<4//i=1,1<4
		{
			System.out.println(b[i]);//a[0]//a[1]
		}
		
		for(int y:b)
		{
			System.out.println(y);
		}
		
		
		
		

	}

}
