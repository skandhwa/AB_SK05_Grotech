package AccessModifier1Ex;

public class UsingPublicAM2 {

	public static void main(String[] args) {
		
		
		UsingPublicModifier obj=new UsingPublicModifier();
		obj.display();

	}

}
