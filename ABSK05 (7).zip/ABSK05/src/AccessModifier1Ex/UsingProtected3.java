package AccessModifier1Ex;

import EncapsulationAndAccessModifiers.UsingProtected1;



public class UsingProtected3 extends UsingProtected1 {

	public static void main(String[] args) {
		
		UsingProtected3 obj=new UsingProtected3();
		obj.test1();
		
		
		

	}

}
