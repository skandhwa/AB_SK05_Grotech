package KeyWordsinJava;

class Emp10
{
	static int add(int x,int y)
	{
		return x+y;
	}
	
	static int sub(int x,int y)
	{
		return x-y;
	}

}
public class StaticMethodExample2 {

	public static void main(String[] args) {
		
	System.out.println(Emp10.add(20, 30));	
		
	System.out.println    ( Emp10.sub(50,20));
	}

}
