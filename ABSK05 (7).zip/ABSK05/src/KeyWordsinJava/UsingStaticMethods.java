package KeyWordsinJava;

class Emp8
{
	static void display()
	{
		System.out.println("Hello team");
	}
}

public class UsingStaticMethods {

	public static void main(String[] args) {
		
//		Emp8 obj=new Emp8();
//		obj.display();
		
		Emp8.display();
		
		
		


	}

}
