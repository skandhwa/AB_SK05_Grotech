package KeyWordsinJava;


class Emp11
{
	static void display()
	{
		System.out.println("i am display method");
	}
}

class Emp12 extends Emp11
{
	void display()
	{
		System.out.println("i am new  display method");
	}
}



public class UsingSuperKeywordinStaticMethod {

	public static void main(String[] args) {
		

	}

}
