package KeyWordsinJava;

class E4
{
	static String name="TCS";
}

class E5 extends E4
{
	static  String name="Infosys";
	
	static void display()
	{
		System.out.println(name);
		System.out.println(super.name);
	}
}




public class UsingSuperVariablesinStatic {

	public static void main(String[] args) {
		
		E5.display();
		

	}

}
