package KeyWordsinJava;

class D6
{
	static String name;
	static int id;
	D6(String name,int id)
	{
		this.name=name;
		this.id=id;
	}
	
	static void display()
	{
		System.out.println(name+" "+id);
	}
	
}

public class UsingThisinStatic {

	public static void main(String[] args) {
		D6 ob=new D6("Mark",1234);
		ob.display();
		

	}

}
