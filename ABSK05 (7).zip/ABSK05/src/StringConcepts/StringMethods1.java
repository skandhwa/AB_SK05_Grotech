package StringConcepts;

public class StringMethods1 {

	public static void main(String[] args) {
		
		String str="India";
		int x=str.length();
		System.out.println(x);
		
		///charAt
		
	char ch=	str.charAt(2);
	
	System.out.println(ch);
	
	String str1="Republic";
	char ch1=str1.charAt(4);
	System.out.println(ch1);
	
	
	
		

	}

}
