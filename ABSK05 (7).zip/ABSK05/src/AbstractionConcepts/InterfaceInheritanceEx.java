package AbstractionConcepts;

interface D1
{
	void show();
	int add(int x,int y);
	int add(int x,int y,int z);
}
interface D2 extends D1
{
	void print();
	int add(int x,int y);
}

interface D3 extends D2
{
	void message();
	int add(int x,int y);
}

class H1 implements D3
{

	
	public void print() {
		
		System.out.println("Print Method");
		
	}


	public void show() {
		
		System.out.println("show Method");
	}

	
	public int add(int x, int y, int z) {
		
		return x+y+z;
		
	}

	
	public void message() {
		System.out.println("message Method");
		
	}

	
	public int add(int x, int y) {
		return x+y;
		
		
		
	}
	
	
	
}
public class InterfaceInheritanceEx {

	public static void main(String[] args) {
		
		D3 ref=new H1();
	System.out.println(ref.add(12, 34));	
		ref.show();
		ref.print();
		System.out.println(	ref.add(23, 45, 78));
		
		D2 ref1=new H1();
		System.out.println	(ref1.add(45, 78));
		
		D1 ref2=new H1();
		System.out.println	(ref2.add(65, 78));
				
		
		

	}

}
