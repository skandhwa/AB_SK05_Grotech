package AbstractionConcepts;

interface A1
{
	int x=20;
	 void display();
	 void test();
	
}

class B10 implements A1
{
	public void display()
	{
		//x=40;
		System.out.println("I am display method");
	}
	public void test()
	{
		System.out.println("I am test method");
	}
	
}
public class InterfaceExample1 {

	public static void main(String[] args) {
		
//		B10 obj=new B10();
//		obj.display();
//		obj.test();
		
		
		A1 ref=new B10();
		ref.display();
		ref.test();
		

	}

}
