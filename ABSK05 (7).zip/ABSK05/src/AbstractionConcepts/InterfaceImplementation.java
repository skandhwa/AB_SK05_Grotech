package AbstractionConcepts;

interface G5
{
	void test();
}

//interface G6 implements G5
//{
//	
//}



public class InterfaceImplementation {

	public static void main(String[] args) {
		
		
		
		

	}

}
