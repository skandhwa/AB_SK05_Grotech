package PolyMorphism;

public class OverloadingMainMethod {
	
	public static int main(String x)
	{
		return 10;
		
	}
	
	public static void main(String x,int []a)
	{
		System.out.println("Hello");
	}
	
	
	
	public static void main(String[] args) {
		
		
		System.out.println("Hello i am original main");
		
		OverloadingMainMethod.main("Saurabh");
		
		

	}

}
