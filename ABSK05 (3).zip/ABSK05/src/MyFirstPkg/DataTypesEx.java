package MyFirstPkg;

public class DataTypesEx {

	public static void main(String[] args) {
		
		boolean flag=false;
		
		byte x=127;
		
		short y=-31239;
		
		int h=700033;
		
		long k=12321321323231221l;
		
		float z=123123213313243243243234324324324212.12321312321234324323234234324324321212f;
		
		float j=234.5f;
		
		double p=21312321323213.2342432324324;
		
		char q='1';
		
	
	

	}

}
