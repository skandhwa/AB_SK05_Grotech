package MyFirstPkg;

public class MethodWithReturnType {
	
	int sum()
	{
		int x=20;
		int y=30;
		
		
		return x+y;
	}

	public static void main(String[] args) {
		
		MethodWithReturnType obj=new MethodWithReturnType();
	System.out.println(obj.sum());	
		
		

	}

}
