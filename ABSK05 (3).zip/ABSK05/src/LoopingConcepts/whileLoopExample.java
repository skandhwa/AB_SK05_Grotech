package LoopingConcepts;

public class whileLoopExample {

	public static void main(String[] args) {
		
		int i=1;///initialization
		
		while(i<5)//1<5//2<5//3<5//4<5//5<5///condition checking
		{
			System.out.println(i);//1//2//3//4
			i++;///increment/decrement operation
		}
		

	}

}
