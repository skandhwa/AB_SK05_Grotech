package AdvanceSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingUploadOperation {

	public static void main(String[] args) throws InterruptedException {
		
		
		WebDriver driver= new ChromeDriver();
		driver.get("https://grotechminds.com/registration/");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.xpath("//input[@id='file']"));
		ele.sendKeys("C:\\Users\\saura\\Downloads\\Assignment 02_GrotecMinds.txt");
		Thread.sleep(5000);
	WebElement ele2=	driver.findElement(By.xpath("//input[@id='relocate']"));
	boolean flag=	ele2.isSelected();
	System.out.println(flag);
	
	if(flag==false)
	{
		ele2.click();
	}
		
		

	}

}
