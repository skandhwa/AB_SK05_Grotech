package SeleniumCommands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElementCommands2Ex {

	public static void main(String[] args) {
	
		WebDriver driver=new ChromeDriver();
		driver.get("https://grotechminds.com/flights/");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.xpath("(//input[@type='radio'])[1]"));
	
	boolean flag=ele.isDisplayed();
	System.out.println(flag);
	
	if(ele.isDisplayed()==true)
	{
		ele.click();
	}
	
	
	
WebElement ele3=	driver.findElement(By.xpath("//input[@name='Returnon']"));

boolean flag2=ele3.isEnabled();
System.out.println("Is the element enabled "+flag2);





	
		

	}

}
