package SeleniumCommands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class UsingisEnabled {

	public static void main(String[] args) {
		
		
		///////    //input[@id='datepicker1']
		
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Datepicker.html");
		driver.manage().window().maximize();
     WebElement ele=     driver.findElement(By.xpath("//input[@id='datepicker1']"));
     
   boolean flag=  ele.isEnabled();
   System.out.println(flag);

	}

}
