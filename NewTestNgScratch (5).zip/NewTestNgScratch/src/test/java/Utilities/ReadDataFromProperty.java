package Utilities;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import Constant.constant;

public class ReadDataFromProperty {
	
	constant obj=new constant();
	
	public Properties  ReadDataProperty() throws IOException 
	{
		FileReader reader=new FileReader(obj.PROPERTYFILEPATH);
		Properties prop=new Properties();
		prop.load(reader);
		
		return prop;
		
	}
	
	

}
