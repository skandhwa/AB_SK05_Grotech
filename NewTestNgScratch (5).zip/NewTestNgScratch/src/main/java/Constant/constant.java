package Constant;

public class constant {
	
	public static final String TESTDATAPATH="src\\main\\java\\TestData\\NewTestDataPath24thJuly.xlsx";
    public static final String PROPERTYFILEPATH="E:\\EclipseWorkspace\\NewTestNgScratch\\src\\main\\java\\Constant\\GlobalData.properties";
    
}
