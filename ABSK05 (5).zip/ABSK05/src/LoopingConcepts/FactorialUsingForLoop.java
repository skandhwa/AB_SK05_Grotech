package LoopingConcepts;

public class FactorialUsingForLoop {

	public static void main(String[] args) {
		
		int i,num=3;
		int fact=1;
		
		
		for(i=1;i<=num;i++)//i=1,1<3//i=2,2<3//i=3,3<=3
		{
			fact=fact*i;//fact=1*1=1//fact=1*2//fact=2*3=6
		}
		
		
//		for(i=num;i>=0;i--)//i=1,1<3//i=2,2<3//i=3,3<=3
//		{
//			fact=fact*i;//fact=1*1=1//fact=1*2//fact=2*3=6
//		}
//		
		
		System.out.println(fact);
		

	}

}
