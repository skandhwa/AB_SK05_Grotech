package TestNgPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class UsingInvokationCount {
	
	@Test(invocationCount=1)
	public void test1()
	{
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
	}
	
	
	@Test(timeOut=3)
	public void test2() throws InterruptedException
	{
		WebDriver driver=new ChromeDriver();
		Thread.sleep(5000);
		driver.get("https://www.google.com");
	}
	
	

}
