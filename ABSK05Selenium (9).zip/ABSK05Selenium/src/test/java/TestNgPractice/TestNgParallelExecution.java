package TestNgPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class TestNgParallelExecution {
	
	public WebDriver driver;
	@Test
	public void google()
	{
		driver=new ChromeDriver();
		driver.get("https://www.google.com");
		String title=driver.getTitle();
		System.out.println(title);
	}
	
	public void instagram()
	{
		driver=new ChromeDriver();
		driver.get("https://www.instagram.com");
		String title=driver.getTitle();
		System.out.println(title);
	}
	
	public void linkedin()
	{
		driver=new ChromeDriver();
		driver.get("https://www.linkedin.com");
		String title=driver.getTitle();
		System.out.println(title);
	}
	public void bigbasket()
	{
		driver=new ChromeDriver();
		driver.get("https://www.bigbasket.com");
		String title=driver.getTitle();
		System.out.println(title);
	}
	
	
	
	@Test
	public void amazon()
	{
		driver=new ChromeDriver();
		driver.get("https://www.amazon.com");
		String title=driver.getTitle();
		System.out.println(title);
	}
	
	
	@Test
	public void flipkart()
	{
		driver=new ChromeDriver();
		driver.get("https://www.flipkart.com");
		String title=driver.getTitle();
		System.out.println(title);
	}
	
	
	@Test
	public void facebook()
	{
		driver=new ChromeDriver();
		driver.get("https://www.facebook.com");
		String title=driver.getTitle();
		System.out.println(title);
	}
	

}
