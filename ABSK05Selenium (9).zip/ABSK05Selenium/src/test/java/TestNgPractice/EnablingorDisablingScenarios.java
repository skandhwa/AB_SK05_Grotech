package TestNgPractice;

import org.testng.annotations.Test;

public class EnablingorDisablingScenarios {
	
	@Test
	public void test()
	{
		System.out.println("Hello I am test method");
	}
	
	@Test(enabled=false)
	public void test2()
	{
		System.out.println("Hello I am test2 method");
	}

}
