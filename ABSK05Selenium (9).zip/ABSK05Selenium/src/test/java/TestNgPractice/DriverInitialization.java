package TestNgPractice;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DriverInitialization {
	
	
	public static  WebDriver getDriver()
	{
		 WebDriver driver;
		 driver=new ChromeDriver();
		 return driver;
		
	}

}
