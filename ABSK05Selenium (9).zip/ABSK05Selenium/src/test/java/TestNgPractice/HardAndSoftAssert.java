package TestNgPractice;

import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;



public class HardAndSoftAssert {
	
	@Test
	public void validate()
	{
		SoftAssert obj=new SoftAssert();
		System.out.println("Soft assertion started");
		int x=8;
		int y=10/2;
		obj.assertEquals(x,y);
		
		int a=10;
		int b=20;
		int c=a+b;
		System.out.println("The sum of a and b is "+c);
		
	}
	
	
	

}
