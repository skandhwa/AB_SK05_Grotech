package AdvanceSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingSingleFrame {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver= new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Frames.html");
		driver.manage().window().maximize();
		driver.switchTo().frame("singleframe");
		Thread.sleep(3000);
	WebElement ele=	driver.findElement(By.xpath("(//input[@type='text'])[1]"));
          ele.sendKeys("Saurabh");
          Thread.sleep(3000);
          driver.switchTo().defaultContent();
          driver.findElement(By.xpath("//a[@href='#Multiple']")).click();
	}

}
