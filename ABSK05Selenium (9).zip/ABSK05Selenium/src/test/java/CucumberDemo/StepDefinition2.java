package CucumberDemo;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.en.And;
import io.cucumber.java.en.But;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition2 {
	
	public WebDriver driver;
	
	@Before
	public void display()
	{
		System.out.println("Hello I am before hooks");
	}
	
	@Before("@Test1")
	public void taggedbefore()
	{
		System.out.println("Hello I am tagged  before hooks");
	}
	
	@After
	public void test()
	{
		System.out.println("Hi I am after hooks");
	}
	
	@After("@Test2")
	public void test3()
	{
		System.out.println("Hi I am tagged after hooks");
	}
	
	
	@Given("the user opens the url into his browser")
	public void the_user_opens_the_url_into_his_browser() {
	    
		System.out.println("Hello");
		
	}

	@But("I am entering an email address which says I am already registered")
	public void i_am_entering_an_email_address_which_says_i_am_already_registered() {
	    
		System.out.println("Hi");
		
	}

	@And("user will enter the username")
	public void user_will_enter_the_username() {
		
		System.out.println("Hello User");
	    
	}

	@And("user will also enter his password")
	public void user_will_also_enter_his_password() {
	 
		System.out.println("Hello User 2");
		
	}

	@When("user will click on the submit button of application")
	public void user_will_click_on_the_submit_button_of_application() {
		
		System.out.println("Hi User 2");
	    
	}

	@Then("user will be able to login into the application")
	public void user_will_be_able_to_login_into_the_application() {
		
		System.out.println("Hi User 3");
	    
	}
	
	
	@Given("I am entering an email address with incorrect details")
	public void i_am_entering_an_email_address_with_incorrect_details() {
		
		System.out.println("Hello all");
	   
	}

	@Given("error will pop up")
	public void error_will_pop_up() {
		
		System.out.println("Hi i am new4");
	    
	}

	@Given("when i resolve the email id")
	public void when_i_resolve_the_email_id() {
	   
		
		System.out.println("Hi  I am new 5");
	}

	@Given("enter the password")
	public void enter_the_password() {
		
		System.out.println("I am new 6");
	    
	}

	@When("I will click on submit button")
	public void i_will_click_on_submit_button() {
		System.out.println("I am new 7");
	    
	}

	@Then("I will be able to navigate to home page")
	public void i_will_be_able_to_navigate_to_home_page() {
		System.out.println("I am new 8");
	    
	}
	
	@Given("user will enter the {string}")
	public void user_will_enter_the(String string) {
	    
		System.out.println("I am new 9");
	}

	@Given("user will also enter his {string}")
	public void user_will_also_enter_his(String string) {
		
		System.out.println("I am new 10");
	   
	}
	
	@Given("User opens the url")
	public void user_opens_the_url() {
	   
		System.out.println("I am background1");
		
	}

	@Given("User types the username")
	public void user_types_the_username() {
		
		System.out.println("I am background2");
	   
	}
	@Given("user types the password")
	public void user_types_the_password() {
		
		System.out.println("I am background3");
	   
	}
	
	@When("User clicks on New Admin")
	public void user_clicks_on_new_admin() {
		
		System.out.println("I am admin code 1");
	   
	}

	@When("user will enter all the details for admin")
	public void user_will_enter_all_the_details_for_admin() {
	    
		System.out.println("I am admin code 2");
	}

	@Then("User will create a new admin")
	public void user_will_create_a_new_admin() {
		
		System.out.println("I am admin code 3");
	   
	}

	@When("User clicks on New Customer")
	public void user_clicks_on_new_customer() {
		
		System.out.println("I am customer code 1");
	   
	}

	@When("user will enter all the details for customer")
	public void user_will_enter_all_the_details_for_customer() {
		
		System.out.println("I am customer code 2");
	   
	}

	@Then("User will create a new customer")
	public void user_will_create_a_new_customer() {
		
		System.out.println("I am customer code 3");
	   
	}


	
	@Given("User is on home page of application")
	public void user_is_on_home_page_of_application() {
	    
		System.out.println("hello");
		
	}

	@Given("User is trying to create a new ustomer with following details")
	public void user_is_trying_to_create_a_new_ustomer_with_following_details(DataTable usercredentials) {
	   
		System.out.println("New details added");
		
		List<List<String>> data=usercredentials.asLists(String.class);
		
		
	driver.findElement(By.xpath(" ")).sendKeys(data.get(0).get(0));	
	driver.findElement(By.xpath(" ")).sendKeys(data.get(0).get(1));
	driver.findElement(By.xpath(" ")).sendKeys(data.get(1).get(0));	
	driver.findElement(By.xpath(" ")).sendKeys(data.get(1).get(1));	
		
		
	}

	@Given("customers are created successfully")
	public void customers_are_created_successfully() {
	    
	}



	

}
