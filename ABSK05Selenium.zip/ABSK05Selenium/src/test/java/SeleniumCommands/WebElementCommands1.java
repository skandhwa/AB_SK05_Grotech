package SeleniumCommands;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class WebElementCommands1 {

	public static void main(String[] args) {
		
		WebDriver driver=new ChromeDriver();
		driver.get("https://grotechminds.com/registration/");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.xpath("//input[@id='fname']"));
		ele.sendKeys("Saurabh");
		
		driver.findElement(By.xpath("//input[@id='fname']")).sendKeys("Saurabh");
		driver.findElement(By.id("lname")).sendKeys("Kandhway");
		driver.findElement(By.name("email")).sendKeys("sk1234@gmail.com");
	List<WebElement> li=	driver.findElements(By.tagName("input"));
	System.out.println(li.size());
	
	
		
		
		

	}

}
