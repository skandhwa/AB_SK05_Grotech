package KeyWordsinJava;

class D4
{
	D4()
	{
		System.out.println("Hello");
	}
	
	D4(int x)
	{
		this();
		System.out.println(x);
	}
}

public class ThisForConstructor {

	public static void main(String[] args) {
		
		
		//D4 obj1=new D4();
		D4 obj=new D4(6);
		//System.out.println();
		

	}

}
