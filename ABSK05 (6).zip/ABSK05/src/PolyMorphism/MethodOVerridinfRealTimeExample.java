package PolyMorphism;


class Bank
{
	int getROI(int x,int z)///method declaration
	{
		return x+z;///Method defination
	}
	
	
	
	
}

class HDFC extends Bank
{
	int getROI(int x,int z)
	{
		return x+z;
	}
}

class Axis extends Bank
{
	int getROI(int x,int z)
	{
		return x+z;
	}
}

class SBI extends Bank
{
	int getROI(int x,int z)
{
	return x+z;
}
	
}

public class MethodOVerridinfRealTimeExample {

	public static void main(String[] args) {
		
		Bank obj=new Bank();
	System.out.println(obj.getROI(3,4));	
	
	SBI obj1=new SBI();
	System.out.println(obj.getROI(4,4));	
		

	}

}
