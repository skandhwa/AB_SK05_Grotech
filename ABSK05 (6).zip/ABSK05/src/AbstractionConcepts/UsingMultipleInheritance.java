package AbstractionConcepts;


interface G1
{
	void print();
}

interface G2
{
	void show();
}

class J1 implements G1,G2
{

	
	public void show() 
	{
		System.out.println("I am show");
		
	}
	public void print() {
		
		System.out.println("I am print");
		
		
	}
	
}
public class UsingMultipleInheritance {

	public static void main(String[] args) {
		
//		G1 ref=new J1();
//		ref.print();
//		
//		G2 ref1=new J1();
//		ref1.show();
		
		J1 obj=new J1();
		obj.print();
		obj.show();
		
		
		

	}

}
