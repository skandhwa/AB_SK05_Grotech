package LoopingConcepts;

public class dowhileExample2 {

	public static void main(String[] args) {
		
		int x=5;
		int sum=0;
		
		do
		{
			sum+=x;//sum=sum+x=0+5=5//sum=5+4=9//sum=9+3=12//sum=12+2=14//sum=14+1=15
			x--;//4//3//2//1//0
		}
		
		while(x!=0);//
		
		System.out.println(sum);
		
		

	}

}
