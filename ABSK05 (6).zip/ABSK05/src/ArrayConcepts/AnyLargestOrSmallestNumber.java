package ArrayConcepts;

import java.util.Arrays;

class ThirdLargest
{
	public static int getSecondLargest(int a[],int total)
	{
		Arrays.sort(a);
		return a[total-2];
		
	}
}

public class AnyLargestOrSmallestNumber {
	
	public static void main(String[] args) {
		
		int a[]= {6,19,2,4,7,1,3,56,14,34,78,11,8,45,98};
		int x=a.length;
	System.out.println(ThirdLargest.getSecondLargest(a,x));	
		
		
		

	}

}
