package EncapsulationAndAccessModifiers;

import AccessModifier1Ex.UsingPublicModifier;

public class UsingPublicAM3 {

	public static void main(String[] args) {
		
		
		UsingPublicModifier obj=new UsingPublicModifier();
		obj.display();

	}

}
