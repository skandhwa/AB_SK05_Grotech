package EncapsulationAndAccessModifiers;

import java.util.ArrayList;
import java.util.List;



public class UsingLists {

	public static void main(String[] args) {
		
		List<Integer> al=new ArrayList<Integer>();
		
		
	}

}
