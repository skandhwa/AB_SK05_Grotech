package InheritanceConcepts;

class A7
{
	String colour="red";
	String str="India" ;///instance
}

class B7 extends A7
{
	String colour="white";
	void display()
	{
		System.out.println(colour);
		System.out.println(super.colour);
		System.out.println(str);
	}
}

public class SuperVariableExample {

	public static void main(String[] args) {
		
		B7 obj=new B7();
		obj.display();
		
		
		

	}

}
