package MyFirstPkg;

class C1
{
	int x;
	float y;
	float z;
	
	 C1(int p,float z)
	{
		x=p;
		y=z;
	}
	 
	
	 
	 void display()
	 {
		 System.out.println(x+"  "+y);
	 }
	
	
}

public class ParameterizedConstructor {

	public static void main(String[] args) {
		
		C1 obj=new C1(23,67.5f);
		obj.display();
		

	}

}
