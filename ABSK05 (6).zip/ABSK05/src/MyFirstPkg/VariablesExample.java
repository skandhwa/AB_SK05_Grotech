package MyFirstPkg;

public class VariablesExample {

	public static void main(String[] args) {
		
		
		
		

	}

}
