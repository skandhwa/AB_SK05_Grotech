package AdvanceSelenium;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingAlerts {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver= new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Alerts.html");
		driver.manage().window().maximize();
		///Handling Simple Alerts
		
//		Thread.sleep(5000);
//		driver.findElement(By.xpath("//button[@class='btn btn-danger']")).click();
//		Thread.sleep(5000);
//		driver.switchTo().alert().accept();
//		Thread.sleep(5000);
		
		
		////Handling Confirmation Alerts
		
		
//		driver.findElement(By.xpath("//a[@href='#CancelTab']")).click();
//		Thread.sleep(5000);
//		driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();
//		Thread.sleep(5000);
//		//driver.switchTo().alert().accept();
//		driver.switchTo().alert().dismiss();
		
		///Handling Prompt Alert
		
		driver.findElement(By.xpath("//a[@href='#Textbox']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//button[@class='btn btn-info']")).click();
		Thread.sleep(5000);
		
		Alert alert=driver.switchTo().alert();
		alert.sendKeys("Saurabh");
		alert.dismiss();
		
	WebElement ele=	driver.findElement(By.xpath("//p[@id='demo1']"));
	String value= ele.getText();	
	System.out.println(value);
		
		
		
		
		
		
		
		
		
		
		

	}

}
