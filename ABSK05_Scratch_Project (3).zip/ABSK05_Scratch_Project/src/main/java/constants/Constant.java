package constants;

public class Constant {

	public static final String TestDataPath="src\\main\\java\\TestData\\NewTestDataPath24thJuly.xlsx";
	public static final String PropertyFilePath="src\\main\\java\\constants\\Global.properties";
	
	
}
