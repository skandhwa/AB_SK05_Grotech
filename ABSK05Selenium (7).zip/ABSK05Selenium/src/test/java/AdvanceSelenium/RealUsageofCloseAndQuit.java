package AdvanceSelenium;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class RealUsageofCloseAndQuit {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver= new ChromeDriver();
		driver.get("https://demo.automationtesting.in/Windows.html");
		driver.manage().window().maximize();
		String WindowID=	driver.getWindowHandle();
		System.out.println(WindowID);
		
		driver.findElement(By.xpath("//a[@href='#Multiple']")).click();
		driver.findElement(By.xpath("(//button[@class='btn btn-info'])[2]")).click();
		
		
		Set<String> windowIDs=	driver.getWindowHandles();
		System.out.println("Window handle values are");
		
		for(String x:windowIDs)
		{
			System.out.println(x);
		}
		
		Thread.sleep(5000);
		
		driver.quit();

	}

}
