package AdvanceSelenium;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingDynamicWebTableNew {

	public static void main(String[] args) {
		
		WebDriver driver= new ChromeDriver();
		driver.get("file:///C://Users//saura//Downloads//WebTable.html");
		driver.manage().window().maximize();
		//driver.findElement(By.xpath("//td[contains(text(),'Ammy')]//preceding-sibling::td//input[@type='checkbox']")).click();
		
		driver.findElement(By.xpath("//input[@name='select2']")).click();
		

	}

}
