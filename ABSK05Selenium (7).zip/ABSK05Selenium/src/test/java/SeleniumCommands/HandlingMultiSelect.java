package SeleniumCommands;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class HandlingMultiSelect {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.techlistic.com/p/selenium-practice-form.html");
		driver.manage().window().maximize();
	WebElement ele=	driver.findElement(By.xpath("//select[@id='selenium_commands']"));
	
	Select oselect=new Select(ele);
 boolean flag=	oselect.isMultiple();
 System.out.println(flag);
 
 oselect.selectByIndex(0);
 oselect.selectByIndex(1);
 oselect.selectByIndex(2);
 
 Thread.sleep(5000);
 //oselect.deselectAll();
 
 //oselect.deselectByIndex(0);
 oselect.deselectByIndex(1);
 //oselect.deselectByIndex(2);
	

	}

}
