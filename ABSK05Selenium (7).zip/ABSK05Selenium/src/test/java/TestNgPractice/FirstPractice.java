package TestNgPractice;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class FirstPractice {
	
	@AfterSuite
	public void method1()
	{
		System.out.println("I am after suite");//6
	}
	
	@BeforeMethod
	public void method2()
	{
		System.out.println("I am BeforeMethod");///2
	}
	
	@BeforeClass
	public void method3()
	{
		System.out.println("I am BeforeClass");///1
	}
	
	@AfterMethod
	public void method4()
	{
		System.out.println("I am AfterMethod ");///4
	}
	
	@AfterClass
	public void method5()
	{
		System.out.println("I am AfterClass ");///5
	}
	
	@Test
	public void method6()
	{
		System.out.println("I am TestMethod ");///3
	}
	
	
	
	

}
