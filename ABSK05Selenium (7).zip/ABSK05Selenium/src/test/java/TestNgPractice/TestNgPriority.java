package TestNgPractice;

import org.testng.Reporter;
import org.testng.annotations.Test;

public class TestNgPriority {
	
	@Test(priority=0)
	public void test1()
	{
		System.out.println("This is 0 priority");///3
	}
	
	@Test(priority=0)
	public void test2()
	{
		System.out.println("This is 0 t2 priority");///4
	}
	
	@Test(priority=-4)
	public void test3()
	{
		System.out.println("This is -4 priority");///2
	}
	
	@Test(priority=6)
	public void Atest4()
	{
		System.out.println("This is 6 priority");//6
	}
	
	@Test
	public void message()
	{
		System.out.println("This is message default priority");//6
	}
	
	
	@Test
	public void display()
	{
		System.out.println("This is display default priority");//5
	}
	
	@Test(priority='A')
	public void test6()
	{
		System.out.println("This is character A priority");///7
	}
	
	
	@Test(priority=-10)
	public void Btest4()
	{
		System.out.println("This is -10 priority");///1
		Reporter.log("My test got passed");
	}
	
	
	
	
	
	
	

}
