package TakingInputFromUser;

import java.util.Scanner;

public class MenuDrivenCalculator {

	public static void main(String[] args) {
		
		int num1,num2;
		double result;
		
		Scanner sc=new Scanner(System.in);
		
		
		
		System.out.println("Enter the first number");
		num1=sc.nextInt();
		
		
		System.out.println("Enter the second number");
		num2=sc.nextInt();
		
		char operator;
		System.out.println("Enter what operation you want to do");
		
		
		operator=sc.next().charAt(0);
		
		while(num1!=0  && num2!=0)
		{
		
		
		
		switch(operator)
		
		{
		
		case '+':
			result=num1+num2;
			System.out.println("The sum is   "  +result);
			break;
			
		case '-':
			result=num1-num2;
			System.out.println("The difference is   "  +result);
			break;	
			
			
		case '*':
			result=num1-num2;
			System.out.println("The product is   "  +result);
			break;		
			
			
		case '/':
			result=num1/num2;
			System.out.println("The division result is   "  +result);
			break;	
			
			
		default:
			System.out.println("Your input is invalid ");
			
		
		
		
		
		}
		
		}
		
		
		System.out.println("You have entered Zero Values so you program wont run");
		
		
		
		
		
		

	}

}
