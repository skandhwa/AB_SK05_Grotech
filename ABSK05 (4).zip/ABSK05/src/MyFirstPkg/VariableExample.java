package MyFirstPkg;



public class VariableExample {
	
	int x=20;///Instance variable
	
	
	void test()
	{
		int y=30;///local variable
		int p=x*y;
		System.out.println(p);
		
	}
	
	 void display()
	{
		int z=40;
		int q=x*z;
		System.out.println(q);
		
	}
	 
	 void message()
	 {
		 int a=50;
		 int b=a*x;
		 System.out.println(b);
	 }
	


	public static void main(String[] args) {
		
		VariableExample obj=new VariableExample();
		obj.display();
		obj.test();
		obj.message();
		
	

	}

}
