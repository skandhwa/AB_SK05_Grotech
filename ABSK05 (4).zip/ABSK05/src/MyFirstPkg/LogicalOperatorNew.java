package MyFirstPkg;

public class LogicalOperatorNew {

	public static void main(String[] args) {
		
		
//		int x=10;
//		int y=25;
//		int z=15;
//		
//		System.out.println (!(x<y || z>y));
		
		
		int p=200;
		int q=40;
		if(p!=q)
		{
			System.out.println("pass");
		}
		
		
		
		

	}

}
