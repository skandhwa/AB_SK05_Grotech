package MyFirstPkg;


class C2
{
	int id;
	String name;
	float salary;
	
	C2(int i,String n)
	{
		id=5;//00010101
		name="Manoj";///00101010
	}
	
	C2(int x,String m,float s)
	{
		id=x;
		name=m;
		salary=s;
		
	}
	
	
	void display()
	{
		System.out.println("id number and name are "+id+"  " +name +" "+salary);
	}
	
	
	
}
public class ParametrizedConstructorEx2 {

	public static void main(String[] args) {
		
		C2 obj=new C2(23,"Tom");
		obj.display();
		
		
		C2 obj1=new C2(34,"Mark",40000f);
		obj1.display();
		
		C2 obj2=new C2(45,"Harry",70000f);
		obj2.display();
		

	}

}
